package invertedIndex;

public interface InputInfo {
    int NUM_OF_COLUMNS = 14;
    String STRING_TYPE = "str";
    String NUM_TYPE = "num";
}
