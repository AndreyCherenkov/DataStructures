package exceptions;

public class NumberColumnException extends Exception{
}
