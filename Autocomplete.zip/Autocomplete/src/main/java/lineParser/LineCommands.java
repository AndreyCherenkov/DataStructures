package lineParser;

public interface LineCommands {
    String DATA_FILE_PATH = "--data";
    String COLUMN_ID = "--indexed-column-id";
    String INPUT_FILE_PATH = "--input-file";
    String OUTPUT_FILE_PATH = "--output-file";
}
